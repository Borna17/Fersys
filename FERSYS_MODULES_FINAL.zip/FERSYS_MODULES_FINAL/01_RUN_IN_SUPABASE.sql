-- FERSYS MODULES FINAL
-- Jednostavnije i sigurnije: postavke modula spremamo direktno na companies,
-- pa koristimo postojeći company RLS i postojeću logiku pristupa tvrtki.

alter table public.companies
  add column if not exists enabled_modules text[] not null
  default array[
    'customers',
    'work_orders',
    'offers',
    'invoices',
    'incoming_invoices',
    'calendar',
    'inventory',
    'vehicles',
    'employees',
    'ai'
  ]::text[];

alter table public.companies
  add column if not exists module_setup_completed boolean not null
  default false;

-- Sve POSTOJEĆE tvrtke ostaju potpuno iste kao do sada.
update public.companies
set
  enabled_modules = array[
    'customers',
    'work_orders',
    'offers',
    'invoices',
    'incoming_invoices',
    'calendar',
    'inventory',
    'vehicles',
    'employees',
    'ai'
  ]::text[],
  module_setup_completed = true
where module_setup_completed = false;

notify pgrst, 'reload schema';
